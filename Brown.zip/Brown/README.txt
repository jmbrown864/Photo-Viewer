Name: Jasmine Brown
Email: jbrown340@gatech.edu
Java Version: 1.8.0_101